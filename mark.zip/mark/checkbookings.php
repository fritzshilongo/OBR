<?php
 include 'connection.php'; 
 include 'inc/features.php';
   
 if (isset($_GET['celloremail'])) {
  $celloremail = $_GET['celloremail'];  
}   

$con;
//collect
  $query = mysqli_query($con, 'SELECT * FROM bookings 

                               JOIN journeys 
                               ON  journeys.JourneysNO = bookings.bookingsJOURNEYNO
                               JOIN companiesanddrivers 
                               ON companiesanddrivers.companiesanddrivers_No = journeys.JourneysCOMPANY
                               JOIN buses 
                               ON buses.BusesNO = journeys.JourneysBUS

                               WHERE bookings.bookingsCELLPHONE = "'.$celloremail.'" OR
                               bookings.bookingsEMAIL = "'.$celloremail.'" OR
                               bookings.bookingsTICKETNUM = "'.$celloremail.'" ');

    $countbookings = mysqli_num_rows($query);
    if ($countbookings == 0) {
       $ALLBOOKINGS = "<div class='row'>
                        <div class='col-sm-12'>
                          <div class='well'> 
                          No data found for $celloremail <a href='index.php' >go back</a>
                          </div>
                        </div>
                      </div>"; 
      }else{
        while ($row = mysqli_fetch_array($query)) {
          //bookings
                         $bookingsNO = $row['bookingsNO'];
                  $bookingsTICKETNUM = $row['bookingsTICKETNUM'];
                  $bookingsJOURNEYNO = $row['bookingsJOURNEYNO'];
                  $bookingsNAMESURNAME = $row['bookingsNAMESURNAME'];
                    $bookingsCELLPHONE = $row['bookingsCELLPHONE'];
                        $bookingsEMAIL = $row['bookingsEMAIL'];
                         $bookingsSEATNUMBER = $row['bookingsSEATNUMBER'];
                           $bookingsDATETIME = $row['bookingsDATETIME'];  
          //journey
                  $JourneysNO = $row['JourneysNO'];
                  $JourneysCOMPANY = $row['JourneysCOMPANY'];
                  $JourneysBUS = $row['JourneysBUS'];
                  $JourneysTICKETPRICE = $row['JourneysTICKETPRICE'];
                  $JourneysSEATS = $row['JourneysSEATS'];
                  $JourneysTAKEN = $row['JourneysTAKEN'];
                    $JourneysDEPDATE = $row['JourneysDEPDATE'];
                    $JourneysDEPTIME = $row['JourneysDEPTIME'];
                    $JourneysDURATION = $row['JourneysDURATION'];
                  $JourneysDEPFROM = $row['JourneysDEPFROM'];
                  $JourneysBOARDINGAREA = $row['JourneysBOARDINGAREA'];
                  $JourneysDEPTOO = $row['JourneysDEPTOO'];
                  $JourneysROUTESTOBETAKEN = $row['JourneysROUTESTOBETAKEN'];
                  $JourneysHITCHHIKERS = $row['JourneysHITCHHIKERS'];
                  $JourneysDRIVERS = $row['JourneysDRIVERS'];
                  $JourneysADDEDON = $row['JourneysADDEDON'];
          //companies
           $companiesanddrivers_No = $row['companiesanddrivers_No'];
                  $companiesanddrivers_Type = $row['companiesanddrivers_Type'];
                 $companiesanddrivers_IdReg = $row['companiesanddrivers_IdReg'];
                  $companiesanddrivers_Name = $row['companiesanddrivers_Name'];
                    $companiesanddrivers_ContactNumberOne = $row['companiesanddrivers_ContactNumberOne'];
                    $companiesanddrivers_ContactNumberTwo = $row['companiesanddrivers_ContactNumberTwo'];
                         $companiesanddrivers_DateOfBirth = $row['companiesanddrivers_DateOfBirth'];
                  $companiesanddrivers_Email = $row['companiesanddrivers_Email'];
               $companiesanddrivers_Password = $row['companiesanddrivers_Password'];
               $companiesanddrivers_JoinDate = $row['companiesanddrivers_JoinDate']; 
          //Buses
                  $BusesNO = $row['BusesNO'];
                  $BusesCOMPANY = $row['BusesCOMPANY'];
                  $BusesIMAGE = $row['BusesIMAGE'];
                  $BusesNUMBER = $row['BusesNUMBER'];
                    $BusesNAME = $row['BusesNAME'];
                    $BusesPLATE = ucwords($row['BusesPLATE']);
                    $BusesSEATS = $row['BusesSEATS'];
                  $BusesKNOWNFOR = $row['BusesKNOWNFOR'];

 $timestamp = strtotime(''.$JourneysDEPTIME.'') + 60*60*$JourneysDURATION;
$ArrivalTime = date('H:i', $timestamp);

$TODAY = date('Y-m-d', strtotime('Today'));
if ($TODAY < $JourneysDEPDATE) {

$then = $JourneysDEPDATE;;
$then = new DateTime($then);
 
$now = new DateTime();
 
$sinceThen = $then->diff($now);
 
//Combined
if ($sinceThen->y > 0) {
 $Y = $sinceThen->y.' years ';
}if ($sinceThen->m > 0) {
 $M = $sinceThen->m.' months ';
}if ($sinceThen->d > 0) {
 $D = $sinceThen->d.' days ';
}
//if ($sinceThen->h > 0) {
 //echo $sinceThen->h.' hours ';
//}if ($sinceThen->i > 0) {
 //echo $sinceThen->i.' minutes';
//}
// echo " to go";
 }else{
  $YMD = "<small class='badge' style='background-color:red;color:white;'>Date Passed</small>";
 }
     $ALLBOOKINGS .= "<div class='row'>
                        <div class='col-sm-12'>
                          <div class='well'>                           
                          <img src='transporter/buses/$BusesIMAGE' height='150' width='150' class='img-rounded' align='right'>
                          <h4><b>From: </b>$JourneysDEPFROM <b>To: </b>$JourneysDEPTOO</h4>
                          <b>Ticket: </b>$bookingsTICKETNUM <b>Seat: </b>$bookingsSEATNUMBER<br>
                          <b>Date: </b>$JourneysDEPDATE $YMD<br>
                          <b>Boarding: </b>$JourneysBOARDINGAREA <br>
                          <b>PAID N$: </b>$JourneysTICKETPRICE   <br>
                          <small><b>booked by $bookingsNAMESURNAME <i>$bookingsEMAIL</i> $bookingsCELLPHONE<br> 
                          $bookingsDATETIME</b></small>                     
                          </div>
                        </div>
                      </div>"; 

        }
   }

?>

 
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Your Bookings</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <style>
    /* Set height of the grid so .sidenav can be 100% (adjust as needed) */
    .row.content {height: 550px}
    
    /* Set gray background color and 100% height */
    .sidenav {
      background-color: #f1f1f1;
      height: 100%;
    }
        
    /* On small screens, set height to 'auto' for the grid */
    @media screen and (max-width: 767px) {
      .row.content {height: auto;} 
    }
  </style>
</head>
<body> 
  <div class="container-fluid">
  <div class="row content">
    <div class="col-sm-3 ">
      <a href=''><h3>YOUR BOOKINGS</h3></a> 
      
      <div class="well">  
        <form method="GET">
        <label>Search Bookings<br> (email, ticket or cellphone number)</label><br>
        <input type="" name="celloremail" value="<?php echo $celloremail;?>" class=form-control autofocus required>
        <button class="btn btn-block btn-success" >CHECK</button>
        </form>
        <label>Results: <?php echo $countbookings;?></label>
      </div> 
      <a href="index.php"><button class="btn btn-block btn-primary btn-bg" >BACK</button></a>
    </div>
    <br> 
    <div class="col-sm-9"> 
      <?php echo $ALLBOOKINGS;?> 
    </div>
  </div>
</div>

</body>
</html>
