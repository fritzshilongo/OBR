<?php
 include 'connection.php'; 
include 'inc/features.php';





if (isset($_GET['bn'])) {
  $bn = $_GET['bn'];
  $cmy = $_GET['cmy'];
}   

$con;
//collect
  $query = mysqli_query($con, 'SELECT * FROM companiesanddrivers WHERE companiesanddrivers.companiesanddrivers_No = "'.$cmy.'"  ');

    $count = mysqli_num_rows($query);
    if ($count == 0) {
       echo "<script type='text/javascript'> alert('page not found');</script>"; 
      header('Location: index.php');
      }else{
        while ($row = mysqli_fetch_array($query)) {
          
                   $companiesanddrivers_No = $row['companiesanddrivers_No'];

                  $companiesanddrivers_Type = $row['companiesanddrivers_Type'];
                 $companiesanddrivers_IdReg = $row['companiesanddrivers_IdReg'];
                  $companiesanddrivers_Name = $row['companiesanddrivers_Name'];

                    $companiesanddrivers_ContactNumberOne = $row['companiesanddrivers_ContactNumberOne'];
                    $companiesanddrivers_ContactNumberTwo = $row['companiesanddrivers_ContactNumberTwo'];
                         $companiesanddrivers_DateOfBirth = $row['companiesanddrivers_DateOfBirth'];

                  $companiesanddrivers_Email = $row['companiesanddrivers_Email'];
               $companiesanddrivers_Password = $row['companiesanddrivers_Password'];
               $companiesanddrivers_JoinDate = $row['companiesanddrivers_JoinDate'];  

if ($companiesanddrivers_Type=="Independent Driver") {
               $Biodetails .="<h4 style='text-transform:uppercase;;'><span class='glyphicon glyphicon-info-sign'></span> $companiesanddrivers_Type</h4>
                                <hr>  
                                <label>Name</label> <br>
                                $companiesanddrivers_Name<br>

                                <label>Contact Number 1</label><br> 
                                $companiesanddrivers_ContactNumberOne<br>

                                <label>Contact Number 2</label><br> 
                                $companiesanddrivers_ContactNumberTwo<br> 

                                <label>Email</label><br>
                                $companiesanddrivers_Email <br>

                                <label>Joined</label><br>
                                $companiesanddrivers_JoinDate 
                                ";
}elseif($companiesanddrivers_Type=="Company"){
               $Biodetails .="<h4 style='text-transform:uppercase;;'><span class='glyphicon glyphicon-info-sign'></span> $companiesanddrivers_Type</h4>
                                <hr>  
                                <label>Company</label> <br>
                                $companiesanddrivers_Name<br>

                                <label>Contact Number 1</label><br> 
                                $companiesanddrivers_ContactNumberOne<br>

                                <label>Contact Number 2</label><br> 
                                $companiesanddrivers_ContactNumberTwo<br> 

                                <label>Email</label><br>
                                $companiesanddrivers_Email <br>

                                <label>Joined</label><br>
                                $companiesanddrivers_JoinDate 
                                ";
}


               


        }
   }

?>


<?php  
if ($companiesanddrivers_Type == "Independent Driver") {
  $HIDETHIS = '';
}else{
  $HIDETHIS = ' JOIN drivers ON drivers.DriversNO = journeys.JourneysDRIVERS ';
}

$con;

//collect
  $query = mysqli_query($con, 'SELECT * FROM journeys 
                               JOIN buses ON buses.BusesNO = journeys.JourneysBUS
                               '.$HIDETHIS.'
                               WHERE journeys.JourneysNO = "'.$bn.'"
                               GROUP BY journeys.JourneysNO  ');

    $count = mysqli_num_rows($query);
    if ($count == 0) { 

      }else{
        while ($row = mysqli_fetch_array($query)) {
          //Journey Table
                   $JourneysNO = $row['JourneysNO'];
                  $JourneysCOMPANY = $row['JourneysCOMPANY'];
                  $JourneysBUS = $row['JourneysBUS'];
                  $JourneysTICKETPRICE = $row['JourneysTICKETPRICE'];
                  $JourneysSEATS = $row['JourneysSEATS'];
                  $JourneysTAKEN = $row['JourneysTAKEN'];
                    $JourneysDEPDATE = $row['JourneysDEPDATE'];
                    $JourneysDEPTIME = $row['JourneysDEPTIME'];
                    $JourneysDURATION = $row['JourneysDURATION'];
                  $JourneysDEPFROM = $row['JourneysDEPFROM'];
                  $JourneysBOARDINGAREA = $row['JourneysBOARDINGAREA'];
                  $JourneysDEPTOO = $row['JourneysDEPTOO'];
                  $JourneysROUTESTOBETAKEN = $row['JourneysROUTESTOBETAKEN'];
                  $JourneysHITCHHIKERS = $row['JourneysHITCHHIKERS'];
                  $JourneysDRIVERS = $row['JourneysDRIVERS'];
                  $JourneysADDEDON = $row['JourneysADDEDON'];

        //Drivers
                   $DriversNO = $row['DriversNO'];
                  $DriversCOMPANY = $row['DriversCOMPANY'];
                  $DriversIMAGE = $row['DriversIMAGE'];
                  $DriversIDNUMBER = $row['DriversIDNUMBER'];
                    $DriversNAMESURNAME = $row['DriversNAMESURNAME'];
                    $DriversCONTACTONE = $row['DriversCONTACTONE'];
                    $DriversCONTACTTWO = $row['DriversCONTACTTWO'];
                  $DriversDATEOFBIRTH = $row['DriversDATEOFBIRTH'];

        //Buses
                  $BusesNO = $row['BusesNO'];
                  $BusesCOMPANY = $row['BusesCOMPANY'];
                  $BusesIMAGE = $row['BusesIMAGE'];
                  $BusesNUMBER = $row['BusesNUMBER'];
                    $BusesNAME = $row['BusesNAME'];
                    $BusesPLATE = ucwords($row['BusesPLATE']);
                    $BusesSEATS = $row['BusesSEATS'];
                  $BusesKNOWNFOR = $row['BusesKNOWNFOR'];
 
$timestamp = strtotime(''.$JourneysDEPTIME.'') + 60*60*$JourneysDURATION;
$ArrivalTime = date('H:i', $timestamp);

$TODAY = date('Y-m-d', strtotime('Today'));
if ($TODAY < $JourneysDEPDATE) {

$then = $JourneysDEPDATE;;
$then = new DateTime($then);
 
$now = new DateTime();
 
$sinceThen = $then->diff($now);
 
//Combined
if ($sinceThen->y > 0) {
 $Y = $sinceThen->y.' years ';
}if ($sinceThen->m > 0) {
 $M = $sinceThen->m.' months ';
}if ($sinceThen->d > 0) {
 $D = $sinceThen->d.' days ';
}
//if ($sinceThen->h > 0) {
 //echo $sinceThen->h.' hours ';
//}if ($sinceThen->i > 0) {
 //echo $sinceThen->i.' minutes';
//}
// echo " to go";
 }else{
  $YMD = "<small class='badge' style='background-color:red;color:white;'>Date Passed</small>";
 }
        }
   }

//collect
  $query = mysqli_query($con, 'SELECT * FROM bookings WHERE bookings.bookingsJOURNEYNO = "'.$bn.'"  ');

    $countbookings = mysqli_num_rows($query);
    if ($countbookings == 0) { 
      $ALLSEATSTAKEN = "<div class='alert alert-success' >
                          <strong>ALL SEATS ARE CURRENTLY AVAILABLE </strong>
                        </div>";
      }else{
        while ($row = mysqli_fetch_array($query)) {
          
                   $bookingsNO = $row['bookingsNO'];

                   $bookingsJOURNEYNO = $row['bookingsJOURNEYNO'];
                 $bookingsNAMESURNAME = $row['bookingsNAMESURNAME'];
                   $bookingsCELLPHONE = $row['bookingsCELLPHONE'];

                         $bookingsEMAIL = $row['bookingsEMAIL'];
                    $bookingsSEATNUMBER = $row['bookingsSEATNUMBER'];
                      $bookingsDATETIME = $row['bookingsDATETIME']; 


                      $ALLSEATSTAKEN .= "<button class='badge' style='background-color:red;color:white;'>$bookingsSEATNUMBER</button> ";
          


        }
   }


?>
 
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bus booking Ticket System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <style>
    /* Set height of the grid so .sidenav can be 100% (adjust as needed) */
    .row.content {height: 550px}
    
    /* Set gray background color and 100% height */
    .sidenav {
      background-color: #f1f1f1;
      height: 100%;
    }
        
    /* On small screens, set height to 'auto' for the grid */
    @media screen and (max-width: 767px) {
      .row.content {height: auto;} 
    }
  </style>
</head>
<body> 
  <div class="container-fluid">
  <div class="row content">
    <div class="col-sm-3 sidenav">
      <a href=''><h3>BOOK NOW</h3></a>
      <a href="index.php"><button class="btn btn-block btn-primary btn-sm">BACK</button></a>
      <div class="well"> 
            <?php echo $Biodetails;?>
      </div>
      <?php 
        echo $SYSALERT;
        echo $SYSALERT1;
      ?>
    </div>
    <br> 
    <div class="col-sm-9"> 
      <div class="row">
        <div class="col-sm-12">
          <div class="well">
            <h4><span class="glyphicon glyphicon-road"></span> Journey</h4>  
            <table class="table" style="font-size: 14px;">
              <tr>
                <td align="right"><b>From:</b></td><td><?php echo $JourneysDEPFROM;?></td>
                <td align="right"><b>To:</b></td><td><?php echo $JourneysDEPTOO;?></td>
                <td align="right"><b>Boarding Station:</b></td><td><?php echo $JourneysBOARDINGAREA;?></td>
              </tr>
              <tr>
                <td align="right"><b>Date:</b></td><td><?php echo $JourneysDEPDATE;?></td>
                <td align="right"><b>Departure:</b></td><td><?php echo $JourneysDEPTIME;?></td> 
                <td align="right"><b>Est Arrival:</b></td><td><?php echo $ArrivalTime?> (<?php echo $JourneysDURATION;?> hours)</td>
              </tr>
              <tr>
                <td align="right"><b>Seats Left:</b></td><td><?php echo $JourneysSEATS - $countbookings;?></td>
                <td align="right"><b>Hitch Hikers:</b></td><td><?php echo $JourneysHITCHHIKERS;?></td>
                <td align="right"><b>Ticket Price:</b></td><td>N$<?php echo $JourneysTICKETPRICE;?></td>
              </tr>
              <tr>
                <td align="right"><b>Added:</b></td><td><?php echo $JourneysADDEDON;?></td>
                <td align="right" colspan="2"><b>Route:</b></td><td><?php echo $JourneysROUTESTOBETAKEN;?></td> 
              </tr>
            </table>
          </div>
        </div>
      </div>
       <div class="row">
        <div class="col-sm-12">
          <div class="well">
            <h4><span class="glyphicon glyphicon-list-alt"></span> Bus <img src="transporter/buses/<?php echo $BusesIMAGE;?>" height='100' width ='100' class='img-rounded' align=right></h4> 
            <b>Bus No:</b> <?php echo $BusesNUMBER;?>
            <b>Name:</b> <?php echo $BusesNAME;?><br>
            <b>Plates:</b> <?php echo $BusesPLATE;?>
            <b>Seats:</b> <?php echo $BusesSEATS;?><br>
            <b>Routes:</b> <?php echo $BusesKNOWNFOR;?>
          </div>
        </div>
      </div>
<?php 
  if($companiesanddrivers_Type=="Company"){
  $hidden = '';
  }elseif($companiesanddrivers_Type=="Independent Driver"){
   $hidden = 'hidden';
  }
?>
      <div class="row" <?php echo $hidden;?>>
        <div class="col-sm-12">
          <div class="well">
            <h4><span class="glyphicon glyphicon-list"></span> Driver <img src="transporter/drivers/<?php echo $DriversIMAGE;?>" height='100' width ='100' class='img-rounded' align=right>  </h4>
            <b>Name:</b> <?php echo $DriversNAMESURNAME;?><br>
            <b>Contact 1:</b> <?php echo $DriversCONTACTONE;?><br>
            <b>Contact 2:</b> <?php echo $DriversCONTACTTWO;?> 
          </div>
        </div>
      </div> 
      <?php
       if ($countbookings == $BusesSEATS) {
         $hiddenITEM = "hidden";
         echo "<div class='alert alert-danger' >
                <strong>OOPS, SORRY BUS IS FULLY BOOKED </strong> <a href='index.php'>go back</a>
              </div>";
       }else{        
        $hiddenITEM = "";
      }
      ?>
      <div class="row">
        <div class="col-sm-8" <?php echo $hiddenITEM;?> >
          <div class="well" >
            <h4><span class="glyphicon glyphicon-ok"></span> Booking & Payment</h4> 
            <form method="POST" >
              <input name="JourneysNO" value="<?php echo $JourneysNO;?>"  hidden>
              <input name="JourneysDEPFROM" value="<?php echo $JourneysDEPFROM;?>" hidden>
              <input name="JourneysDEPTOO" value="<?php echo $JourneysDEPTOO;?>" hidden>
              <input name="JourneysBOARDINGAREA" value="<?php echo $JourneysBOARDINGAREA;?>" hidden>
              <input name="JourneysDEPDATE" value="<?php echo $JourneysDEPDATE;?>" hidden>
              <input name="JourneysDEPTIME" value="<?php echo $JourneysDEPTIME;?>" hidden>
              <input name="JourneysDURATION" value="<?php echo $JourneysDURATION;?>" hidden>
              <input name="ArrivalTime" value="<?php echo $ArrivalTime;?>" hidden>
              <input name="JourneysROUTESTOBETAKEN" value="<?php echo $JourneysROUTESTOBETAKEN;?>" hidden>

              <input name="BusesNAME" value="<?php echo $BusesNAME;?>" hidden>
              <input name="BusesPLATE" value="<?php echo $BusesPLATE;?>" hidden>

              <input name="companiesanddrivers_Name" value="<?php echo $companiesanddrivers_Name;?>" hidden>
              <input name="companiesanddrivers_ContactNumberOne" value="<?php echo $companiesanddrivers_ContactNumberOne;?>" hidden>
              <input name="companiesanddrivers_ContactNumberTwo" value="<?php echo $companiesanddrivers_ContactNumberTwo;?>" hidden> 
              <table>
                <tr>
                  <td colspan="3"><label>Name Surname</label>
                      <input name="NameSurname" class="form-control" placeholder="John Smith" required> </td>
                  <td><label>Cellphone Number</label>
                      <input type=number name="CellphoneNumber" class="form-control" placeholder="0810000000" required></td>
                </tr>
                <tr>
                  <td colspan="3"><label>Email</label>
                      <input type=email name="Email" class="form-control" placeholder="name@example.com" required></td>
                  <td><label>Seat Number</label>
                      <input type=number name="SeatNumber" class="form-control" placeholder="1 to <?php echo $BusesSEATS;?>" required> </td>                  
                </tr>
                          
                  <tr>
                    <td colspan="4"><label>Card Number</label></td>
                  </tr>
                  <tr>
                    <td><input class="form-control" type="number" placeholder="0000" required></td>
                    <td><input class="form-control" type="number" placeholder="0000" required></td>
                    <td><input class="form-control" type="number" placeholder="0000" required></td>
                    <td><input class="form-control" type="number" placeholder="0000" required></td>
                  </tr>
                  <tr>
                    <td colspan="2"><label>Card Holder</label><input class="form-control" placeholder="John Smith" required></td>
                    <td><label>MM</label>
                         <select class="form-control" required>
                             <option></option>
                             <option>01</option>
                             <option>02</option>
                             <option>03</option>
                             <option>04</option>
                             <option>05</option>
                             <option>06</option>
                             <option>07</option>
                             <option>08</option>
                             <option>09</option>
                             <option>10</option>
                             <option>11</option>
                             <option>12</option>
                         </select></td>
                    <td><label>YY</label>
                         <select class="form-control" required>
                             <option></option>
                             <option>19</option>
                             <option>20</option>
                             <option>21</option>
                             <option>22</option>
                             <option>23</option>
                         </select></td>  
                  </tr>
                  <tr>
                    <td><label>CCV</label><input class="form-control"" type="number" placeholder="000" required></td>
                    <td></td>
                    <td></td>
                    <td><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQONoS3KBKAzE4KUEk-0csuRKVUAWh2Tky2Pb_Z6km35IvMLvdO" height="50"></td>
                  </tr>
                  <tr>
                    <td colspan="4"><button class="btn btn-block btn-success" name="PayNow"><label>Pay Now N$<?php echo $JourneysTICKETPRICE;?></label></button><label><?php echo date('Y-m-d h:i', strtotime('+1 hours'));?></label> </td>
                  </tr>
                  <input name="JourneysTICKETPRICE" value="<?php echo $JourneysTICKETPRICE;?>" hidden>        
              </table>
            </form>
          </div>          
        </div>  
        <div class="col-sm-4"  <?php echo $hiddenITEM;?>>
            <div class="well">
              <h4><span class="glyphicon glyphicon-"></span> Seats Taken</h4>
              <?php echo $ALLSEATSTAKEN;?>
            </div>
          </div>
      </div> 
    </div>
  </div>
</div>

</body>
</html>
