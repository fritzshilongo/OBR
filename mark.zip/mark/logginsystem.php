<?php
//error_reporting(0);
require 'connection.php';
if (isset($_POST['LOGIN'])) {
  $loguser = $_POST['loguser'];
  $username = $_POST['useremail'];
  $password = $_POST['userpass']; 

    $result = mysqli_query($con, 'SELECT * FROM companiesanddrivers WHERE companiesanddrivers_Type = "'.$loguser.'" 
                                                                    AND companiesanddrivers_Email = "'.$username.'" 
                                                                    AND companiesanddrivers_Password = "'.$password.'" ');
  if(mysqli_num_rows($result)==1){ 
    session_start();
    $_SESSION['TRANSPORTERloguser'] = $loguser;
    $_SESSION['TRANSPORTERemail'] = $username;
    $_SESSION['TRANSPORTERpassword'] = $password; 
    header('Location: transporter/');
  }else{
   echo "<script type='text/javascript'> alert('Invalid institution details');</script>"; 
} 
  
 
}
 

if (isset($_POST['RESETADMIN'])) {
  
  $useremail = $_POST['useremail']; 

    $result = mysqli_query($con, 'SELECT * FROM qsschools WHERE  qsschoolsLOGINEMAIL = "'.$useremail.'" ');
  if(mysqli_num_rows($result)==1){ 
     if (isset($_POST['RESETADMIN'])) {
  $useremail = $_POST['useremail'];
  $newPASS = rand(1001,9999);
  $subject ='RESET PASSWORD';
  $message = 'Greetings Admin
              Your password has been reset. Here are your new credentials
              EMAIL: '.$useremail.'
              PASSWORD: '.$newPASS.'
              LOG IN @: ';
  $header = '<no -reply>QSEARCH DEMO SYSTEM';
  if (mail($useremail, $subject, $message, $header)) {
    mysqli_query($con,'UPDATE qsschools SET qsschoolsPASSWORD = "'.$newPASS.'" WHERE qsschoolsLOGINEMAIL = "'.$useremail.'" ');
  }else{
  echo "<script type='text/javascript'>alert('Password can't be reset while on local host.))</script>";
  }
 }
  }else{
   echo "<script type='text/javascript'> alert('EMAIL NOT FOUND');</script>"; 
}   
}






?>