<?php 
include 'connection.php';

if (isset($_POST['SignUpDriver'])) {
  $dateofbirth = $_POST['dateofbirth']; 
  $AGEREQ = date('Y', strtotime('-18 Years'));

  if ($AGEREQ < $dateofbirth) {
  echo "";
  $SYSTEMMES = "<div class='alert alert-danger'>
                  <strong><h5>Too Young, Need to be atleast 18.</h5></strong> Failed to add new Driver
                  </div>";
} else 
    include 'newdrivercompany.php';
}

if (isset($_POST['SignUpCompany'])) {
  include 'newdrivercompany.php';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bus booking Ticket System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <style>
    /* Set height of the grid so .sidenav can be 100% (adjust as needed) */
    .row.content {height: 550px}
    
    /* Set gray background color and 100% height */
    .sidenav {
      background-color: #f1f1f1;
      height: 100%;
    }
        
    /* On small screens, set height to 'auto' for the grid */
    @media screen and (max-width: 767px) {
      .row.content {height: auto;} 
    }
  </style>
</head>
<body>

<div class="container-fluid">
  <div class="row content">
    <div class="col-sm-3 sidenav">
      <?php include 'name.php'; ?>
      <ul class="nav nav-pills nav-stacked">
        <li><a href="index.php"><button class="btn btn-primary btn-sm btn-block" >Back</button> </a></li>
        <li><p>Greetings new driver / company, welcome to Bus Ticket System. Here you will be able to obtian customers for your journeys throughout Namibia.<br><b>Its as simple as this:</b></p></li>
      </ul>
      <ol>
        <li><span class="glyphicon glyphicon-info-sign"></span> Enter Information</li>
        <li><span class="glyphicon glyphicon-list-alt"></span> Add your buses</li>
        <li><span class="glyphicon glyphicon-list"></span> Add your drivers (Compaines)</li>
        <li><span class="glyphicon glyphicon-road"></span> Create new Journey</li>
        <li><span class="glyphicon glyphicon-ok"></span> Done!</li>
      </ol>
    </div>
    <br>
    
    <div class="col-sm-9"> 
     <?php echo $SYSTEMMES;?>
     <?php echo $SYSTEMMES1;?>
      <div class="row">
        <div class="col-sm-6">
          <div class="well">
            <h4><span class="glyphicon glyphicon-info-sign"></span> New Driver</h4>
            <hr>
            <form method="POST">
              <input type="" name="usertype" value="Independent Driver" hidden>
              <label>Id Number</label>
              <input type="" name="idnumber" class="form-control" required>
              <label>Name Surname</label>
              <input type="" name="Firstname" class="form-control" required> 
              <label>Contact Number 1</label>
              <input type="" name="contactnumber1" class="form-control" required>
              <label>Contact Number 2</label>
              <input type="" name="contactnumber2" class="form-control" required>
              <label>Date of Birth</label>
              <input type="date" name="dateofbirth" class="form-control" required>
              <label>Email</label>
              <input type="email" name="email" class="form-control" required>
              <label>Password</label>
              <p>System will generate a new password and will send it to your email</p>
              <input type="" name="Password" value="<?php echo rand(9999,99999);?>" hidden>
              <button class="btn btn-block btn-success" name="SignUpDriver">Sign Me Up</button>
            </form>
          </div>
        </div>
        <div class="col-sm-6">
          <div class="well">
            <h4><span class="glyphicon glyphicon-info-sign"></span> New Company</h4>
            <hr>
            <form method="POST">
              <input type="" name="usertype" value="Company" hidden>
              <label>Registration Number</label>
              <input type="" name="Regnumber" class="form-control" required>
              <label>Company Name</label>
              <input type="" name="companyname" class="form-control" required> 
              <label>Contact Number 1</label>
              <input type="" name="contactnumber1" class="form-control" required>
              <label>Contact Number 2</label>
              <input type="" name="contactnumber2" class="form-control" required>
              <label>Email</label>
              <input type="email" name="email" class="form-control" required>
              <label>Password</label>
              <p>System will generate a new password and will send it to your email</p>
              <input type="" name="Password" value="<?php echo rand(9999,99999);?>" hidden>
              <button class="btn btn-block btn-success" name="SignUpCompany">Sign Us Up</button>
            </form>  
          </div>
        </div>
      </div> 
    </div>
  </div>
</div>

</body>
</html>
