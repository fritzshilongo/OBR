-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 28, 2019 at 09:04 AM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 7.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mark_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `bookingsNO` int(55) NOT NULL,
  `bookingsTICKETNUM` varchar(100) NOT NULL,
  `bookingsJOURNEYNO` int(55) NOT NULL,
  `bookingsNAMESURNAME` varchar(200) NOT NULL,
  `bookingsCELLPHONE` varchar(200) NOT NULL,
  `bookingsEMAIL` varchar(200) NOT NULL,
  `bookingsSEATNUMBER` int(50) NOT NULL,
  `bookingsDATETIME` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`bookingsNO`, `bookingsTICKETNUM`, `bookingsJOURNEYNO`, `bookingsNAMESURNAME`, `bookingsCELLPHONE`, `bookingsEMAIL`, `bookingsSEATNUMBER`, `bookingsDATETIME`) VALUES
(1, ' #84521', 4, 'John Smith', '0816963389', 'johnsmith@gmail.com', 12, '2019-02-23 12:41:35'),
(2, ' #18245', 2, 'Jack Danials', '0814567895', 'jack@gmail.com', 13, '2019-02-23 13:03:48'),
(3, ' #17045', 2, 'Ron Micheal', '0814567845', 'mike@gmail.com', 18, '2019-02-23 13:05:06'),
(4, ' #10045', 4, 'Godfrey Smith', '081456789', 'godsmith@gmail.com', 3, '2019-02-23 13:20:31'),
(5, '#10000', 4, 'Vivi Styles', '0816963389', 'johnsmith@gmail.com', 24, '2019-02-23 14:31:14'),
(6, '#10345', 13, 'Jack', '0815856645', 'jack@gmail.com', 17, '2019-02-24 11:04:23'),
(8, '#10034', 13, 'Fred Bug', '0815856645', 'frank@gmail.com', 18, '2019-02-24 11:06:10'),
(9, '#27765', 13, 'Godfrey Smith', '0815856645', 'ronnysitamulaho@gmail.com', 13, '2019-02-24 11:24:25'),
(10, '#79944', 9, 'happy', '0815856645', 'godsmith@gmail.com', 9, '2019-02-24 11:56:41');

-- --------------------------------------------------------

--
-- Table structure for table `buses`
--

CREATE TABLE `buses` (
  `BusesNO` int(100) NOT NULL,
  `BusesCOMPANY` int(100) NOT NULL,
  `BusesIMAGE` varchar(100) NOT NULL,
  `BusesNUMBER` varchar(100) NOT NULL,
  `BusesNAME` varchar(100) NOT NULL,
  `BusesPLATE` varchar(100) NOT NULL,
  `BusesSEATS` int(50) NOT NULL,
  `BusesKNOWNFOR` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buses`
--

INSERT INTO `buses` (`BusesNO`, `BusesCOMPANY`, `BusesIMAGE`, `BusesNUMBER`, `BusesNAME`, `BusesPLATE`, `BusesSEATS`, `BusesKNOWNFOR`) VALUES
(3, 14, '11523.jpg', '3', 'Emanguni', 'n233w', 36, ''),
(4, 14, '25442.png', '1', 'Emanguni', 'N765W', 40, 'Windhoek to Rundu'),
(5, 16, '32526.png', '3', 'Oasis', 'N346W', 40, 'Katima, Rundu, Okahandja'),
(6, 20, '3414.jpg', '6', 'Oasis', 'n233w', 64, 'b1'),
(7, 20, '14143.jpg', '6', 'Emanguni', 'N345S', 64, 'b1');

-- --------------------------------------------------------

--
-- Table structure for table `companiesanddrivers`
--

CREATE TABLE `companiesanddrivers` (
  `companiesanddrivers_No` int(55) NOT NULL,
  `companiesanddrivers_Type` varchar(100) NOT NULL,
  `companiesanddrivers_IdReg` varchar(100) NOT NULL,
  `companiesanddrivers_Name` varchar(200) NOT NULL,
  `companiesanddrivers_ContactNumberOne` varchar(50) NOT NULL,
  `companiesanddrivers_ContactNumberTwo` varchar(55) NOT NULL,
  `companiesanddrivers_DateOfBirth` date NOT NULL,
  `companiesanddrivers_Email` varchar(100) NOT NULL,
  `companiesanddrivers_Password` varchar(100) NOT NULL,
  `companiesanddrivers_JoinDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `companiesanddrivers`
--

INSERT INTO `companiesanddrivers` (`companiesanddrivers_No`, `companiesanddrivers_Type`, `companiesanddrivers_IdReg`, `companiesanddrivers_Name`, `companiesanddrivers_ContactNumberOne`, `companiesanddrivers_ContactNumberTwo`, `companiesanddrivers_DateOfBirth`, `companiesanddrivers_Email`, `companiesanddrivers_Password`, `companiesanddrivers_JoinDate`) VALUES
(14, 'Company', 'REG0009', 'Goon Transport Services', '0816963389', '0816963389', '0000-00-00', 'ronnysitamulaho@gmail.com', '24264', '2019-02-13'),
(16, 'Independent Driver', '95091700129', 'Ronny Sitamulaho', '0816963389', '0816963389', '1987-01-12', 'ronnysitamulaho@gmail.com', '59517', '2019-02-13'),
(20, 'Company', 'jhbh6', 'StoneTransport Services', '0815855822', '0816963389', '2019-02-23', 'ronizmog51@gmail.com', '75876', '2019-02-23');

-- --------------------------------------------------------

--
-- Table structure for table `drivers`
--

CREATE TABLE `drivers` (
  `DriversNO` int(100) NOT NULL,
  `DriversCOMPANY` int(100) NOT NULL,
  `DriversIMAGE` varchar(55) NOT NULL,
  `DriversIDNUMBER` varchar(100) NOT NULL,
  `DriversNAMESURNAME` varchar(100) NOT NULL,
  `DriversCONTACTONE` varchar(100) NOT NULL,
  `DriversCONTACTTWO` varchar(100) NOT NULL,
  `DriversDATEOFBIRTH` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `drivers`
--

INSERT INTO `drivers` (`DriversNO`, `DriversCOMPANY`, `DriversIMAGE`, `DriversIDNUMBER`, `DriversNAMESURNAME`, `DriversCONTACTONE`, `DriversCONTACTTWO`, `DriversDATEOFBIRTH`) VALUES
(1, 14, '5727.jpg', '95091700129', 'Ronny Sitamulaho', '0816963389', '0816963389', '1970-01-12'),
(2, 14, '30996.jpg', '5665365876', 'Joe Bridges', '0815855822', '0815855822', '1993-01-13'),
(3, 20, '4567.png', '9509170767', 'Jack Fredd', '0816963389', '0815855822', '1991-03-24'),
(4, 20, '26636.png', '967854532', 'Goon Jones', '0812343453', '0812343453', '1973-04-04');

-- --------------------------------------------------------

--
-- Table structure for table `journeys`
--

CREATE TABLE `journeys` (
  `JourneysNO` int(100) NOT NULL,
  `JourneysCOMPANY` int(100) NOT NULL,
  `JourneysBUS` int(100) NOT NULL,
  `JourneysSEATS` int(100) NOT NULL,
  `JourneysTAKEN` int(100) NOT NULL,
  `JourneysTICKETPRICE` int(100) NOT NULL,
  `JourneysDEPDATE` date NOT NULL,
  `JourneysDEPTIME` time NOT NULL,
  `JourneysDURATION` int(11) NOT NULL,
  `JourneysDEPFROM` varchar(100) NOT NULL,
  `JourneysBOARDINGAREA` varchar(100) NOT NULL,
  `JourneysDEPTOO` varchar(100) NOT NULL,
  `JourneysROUTESTOBETAKEN` varchar(500) NOT NULL,
  `JourneysHITCHHIKERS` varchar(100) NOT NULL,
  `JourneysDRIVERS` varchar(500) NOT NULL,
  `JourneysADDEDON` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `journeys`
--

INSERT INTO `journeys` (`JourneysNO`, `JourneysCOMPANY`, `JourneysBUS`, `JourneysSEATS`, `JourneysTAKEN`, `JourneysTICKETPRICE`, `JourneysDEPDATE`, `JourneysDEPTIME`, `JourneysDURATION`, `JourneysDEPFROM`, `JourneysBOARDINGAREA`, `JourneysDEPTOO`, `JourneysROUTESTOBETAKEN`, `JourneysHITCHHIKERS`, `JourneysDRIVERS`, `JourneysADDEDON`) VALUES
(9, 20, 6, 64, 0, 500, '2019-03-24', '16:13:00', 12, 'Windhoek', 'Wernhill Bus Stop', 'Katima Mulilo', 'b1', 'No', '3', '2019-02-23 17:14:55'),
(10, 20, 6, 64, 0, 400, '2019-04-24', '18:21:00', 8, 'Windhoek', 'Wernhill Bus Stop', 'Katima Mulilo', 'b1', 'No', '3', '2019-02-23 17:20:43'),
(11, 20, 6, 64, 0, 400, '2019-04-24', '18:21:00', 8, 'Windhoek', 'Wernhill Bus Stop', 'Katima Mulilo', 'b1', 'No', '3', '2019-02-23 17:20:43'),
(12, 20, 6, 64, 0, 700, '2019-03-20', '05:09:00', 4, 'Windhoek', 'Wernhill Bus Stop', 'Okahanja', 'b1', 'No', '3', '2019-02-23 18:11:02'),
(13, 20, 7, 64, 0, 500, '2019-03-25', '10:40:00', 2, 'Windhoek', 'Wernhill Bus Stop', 'Okahanja', 'b1', 'No', '4', '2019-02-24 09:39:39');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`bookingsNO`),
  ADD UNIQUE KEY `bookingsJOURNEYNO` (`bookingsJOURNEYNO`,`bookingsSEATNUMBER`);

--
-- Indexes for table `buses`
--
ALTER TABLE `buses`
  ADD PRIMARY KEY (`BusesNO`),
  ADD UNIQUE KEY `BusesCOMPANY` (`BusesCOMPANY`,`BusesPLATE`);

--
-- Indexes for table `companiesanddrivers`
--
ALTER TABLE `companiesanddrivers`
  ADD PRIMARY KEY (`companiesanddrivers_No`),
  ADD UNIQUE KEY `companiesanddrivers_Type` (`companiesanddrivers_Type`,`companiesanddrivers_Email`),
  ADD UNIQUE KEY `companiesanddrivers_IdReg` (`companiesanddrivers_IdReg`);

--
-- Indexes for table `drivers`
--
ALTER TABLE `drivers`
  ADD PRIMARY KEY (`DriversNO`),
  ADD UNIQUE KEY `DriversCOMPANY` (`DriversCOMPANY`,`DriversIDNUMBER`);

--
-- Indexes for table `journeys`
--
ALTER TABLE `journeys`
  ADD PRIMARY KEY (`JourneysNO`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `bookingsNO` int(55) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `buses`
--
ALTER TABLE `buses`
  MODIFY `BusesNO` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `companiesanddrivers`
--
ALTER TABLE `companiesanddrivers`
  MODIFY `companiesanddrivers_No` int(55) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `drivers`
--
ALTER TABLE `drivers`
  MODIFY `DriversNO` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `journeys`
--
ALTER TABLE `journeys`
  MODIFY `JourneysNO` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
