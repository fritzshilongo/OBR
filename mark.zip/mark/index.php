<?php 
include 'connection.php';
include 'inc/features.php';
if (isset($_POST['LOGIN'])) {
include 'logginsystem.php';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bus booking Ticket System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <style>
    /* Set height of the grid so .sidenav can be 100% (adjust as needed) */
    .row.content {height: 550px}
    
    /* Set gray background color and 100% height */
    .sidenav {
      background-color: #f1f1f1;
      height: 100%;
    }
        
    /* On small screens, set height to 'auto' for the grid */
    @media screen and (max-width: 767px) {
      .row.content {height: auto;} 
    }
  </style>
</head>
<body>

<div class="container-fluid">
  <div class="row content">
    <div class="col-sm-3 sidenav">
      <?php include 'name.php'; ?>
      <ul class="nav nav-pills nav-stacked">
        <li><a href="comsignup.php">Company / Driver Sign up here</a></li>
        <li>
          <form method="POST">
            <label>Transporter Type</label><br>
            <input type="radio" name="loguser" value="Independent Driver"> Independent Driver<br>
            <input type="radio" name="loguser" value="Company"> Company<br>
            <label>Email</label>
            <input type="email" name="useremail" class="form-control" required="" placeholder="Email">
            <label>Password</label>
            <input type="password" name="userpass" class="form-control" required placeholder="Password">
            <button name="LOGIN" class="btn btn-block btn-success btn-lg" ><label>Login</label></button>
          </form>
        </li>
        <li><a href="#section3"></a></li>
        <li><label>Check your bookings here</label>
          <form method="GET" action="checkbookings.php">
            <input type="text" name="celloremail" class="form-control" placeholder="email, ticket or cellphone number">
            <button name="Checkbookings" class="btn btn-block btn-success btn-lg" ><label>Check</label></button>
          </form>
        </li>
      </ul><br>
    </div>
    <br>
    
    <div class="col-sm-9">
      <div class="well">
        <h4>Find Journeys</h4> 
        <form method="GET">
        	<select name="selectjourneys" class="form-control">
            <?php 
              echo $CURRENTDATE;
              echo "<option>View All</option>";
              echo $SelectDate;
            ?>
            
        	</select>
        	<button class="btn btn-primary btn-block" name="searchjourneys">SEARCH</button>
        </form>
        <hr> 
      </div> 
      <div class="row">
        <?php echo $ALLJOURNIES;?> 
      </div>  
    </div>
  </div>
</div>

</body>
</html>
