<?php
 include '../connection.php';
 
 if(isset($_POST['deleteDRIVER'])){
    $DriversNO = $_POST['DriversNO'];
    mysqli_query($con,'DELETE FROM drivers WHERE DriversNO = "'.$DriversNO.'"');
}
if(isset($_POST['deleteBUS'])){
    $BusesNO = $_POST['BusesNO'];
    mysqli_query($con,'DELETE FROM buses WHERE BusesNO = "'.$BusesNO.'"');
}



 if (isset($_POST['AddBus'])) {
   include 'inc/features.php';
 }
if (isset($_POST['AddDriver'])) {
  $dob = $_POST['dateofbirth']; 
  $AGEREQ = date('Y', strtotime('-25 Years'));

  if ($AGEREQ < $dob) {
  echo "<div class='alert alert-danger'>
              <h5>Too Young, Need to be atleast 25 and above.</h5>
        </div>";
} else 
    include 'inc/features.php';
}
 if (isset($_POST['CreateNewJourney'])) {
  $DepDate = $_POST['DepDate'];
  $CurentDate = date('m / d / y');
  if ($DepDate >= $CurentDate) {
   include 'inc/features.php';
  }else{
     echo "<div class='alert alert-danger'>
              <strong>Invalid Departure date</strong>
           </div>";
  }

 }
include 'inc/os.php';
?> 
 
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bus booking Ticket System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <style>
    /* Set height of the grid so .sidenav can be 100% (adjust as needed) */
    .row.content {height: 550px}
    
    /* Set gray background color and 100% height */
    .sidenav {
      background-color: #f1f1f1;
      height: 100%;
    }
        
    /* On small screens, set height to 'auto' for the grid */
    @media screen and (max-width: 767px) {
      .row.content {height: auto;} 
    }
  </style>
</head>
<body>

<div class="container-fluid">
  <div class="row content">
    <div class="col-sm-2 sidenav"> 
      <?php echo $Biodetails;?>
      <center>
            <h4>Image Upload Preview</h4>
            <img id="blah" src="http://placehold.it/180" width="200"  alt="" />
              <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
              <script  src="../js/index.js"></script>
          </center>
      <form method="GET">
        <button name="logout" class="btn btn-danger">Logout</button>
      </form>
    </div>
    <br>
<?php 
  if($companiesanddrivers_Type=="Company"){
  $size = 4;
  }elseif($companiesanddrivers_Type=="Independent Driver"){
   $size = 6;
  }
?>


    <div class="col-sm-9"> 
      <?php
        if ($countbookings == 0) {
          $countbookings = 'hidden';
        }
      ?>
      <h4 <?php echo $countbookings;?>><span class="glyphicon glyphicon-ok"></span> Bookings (<?php echo $countbookings;?>)</h4> 
      
      <div class='row' <?php echo $countbookings;?>>
      <div class='col-sm-12'>
        <div class='well'> 
       <table class="table">
        <thead>
          <tr>
            <th>BUS</th> 
            <th>FROM</th>
            <th>TO</th>
            <th>DATE</th>
            <th>TIME</th> 
            <th>BOOKINGS</th>
          </tr>
        </thead>
         <tbody>
           <?php echo $ALLBOOKINGS;?>
         </tbody>
       </table>
        </div>
      </div>
     </div>
      <div class="row">
        <div class="col-sm-12">
          
        </div>
      </div>
      <div class="row">
        <div class="col-sm-<?php echo $size;?>">
          <div class="well">
            <h4><span class="glyphicon glyphicon-list-alt"></span> Buses</h4> 
            <ol><?php echo $ALLBUSES;?></ol>
            <h4><span class="glyphicon glyphicon-list-alt"></span> Add a New bus</h4>
            <form method="POST" enctype='multipart/form-data'>
              <label>Picture of Bus</label> 
              <input type='file' name='image_upload' onchange='readURL(this);'  class='form-control' required/>
              <input type="" name="companiesanddrivers_No" value="<?php echo $companiesanddrivers_No;?>" hidden>
              <label>Bus Number</label>
              <input type="number" name="BusNumber" class="form-control">
              <label>Bus Name</label>
              <input name="BusName" class="form-control">
              <label>Number Plate</label>
              <input name="PlateNumber" class="form-control" style="text-transform: uppercase;">
              <label>Number of Seats</label>
              <input type="number" name="NumberofSeats" class="form-control">
              <label>Routes Known For</label>
              <textarea name="RoutesKnownFor" class="form-control"></textarea> 
              <button name="AddBus" class="btn btn-block btn-success" ><b>Add This Bus</b></button>
            </form>
          </div>
        </div>

     <?php 
  if($companiesanddrivers_Type=="Company"){
  $hidden = '';
  }elseif($companiesanddrivers_Type=="Independent Driver"){
   $hidden = 'hidden';
  }
?>
       <div class="col-sm-<?php echo $size;?>" <?php echo $hidden;?>>
          <div class="well">
            <h4><span class="glyphicon glyphicon-list"></span> Drivers</h4>
            <ol><?php echo $ALLDRIVERS;?></ol>
            <h4><span class="glyphicon glyphicon-list"></span> Add New Driver</h4>
            
        <form method="POST" enctype='multipart/form-data'>
          <label>Picture of Driver</label>
          <input type='file' name='image_upload' onchange='readURL(this);' class='form-control' required/>
          <input type="" name="companiesanddrivers_No" value="<?php echo $companiesanddrivers_No;?>" hidden> 
              <label>Id Number</label>
              <input type="" name="idnumber" class="form-control" required>
              <label>Name Surname</label>
              <input type="" name="Firstname" class="form-control" required> 
              <label>Contact Number 1</label>
              <input type="" name="contactnumber1" class="form-control" required>
              <label>Contact Number 2</label>
              <input type="" name="contactnumber2" class="form-control" required>
              <label>Date of Birth</label>
              <input type="date" name="dateofbirth" class="form-control" required> 
              <button class="btn btn-block btn-success" name="AddDriver"><b>Add Driver</b></button>
            </form>
          </div>
        </div>

        <div class='col-sm-<?php echo $size;?>'>
          <div class='well'>
            <h4><span class='glyphicon glyphicon-road'></span> Journeys</h4>
            <ol><?php echo $ALLJOURNEY;?></ol>
            <h4><span class='glyphicon glyphicon-road'></span> Create New Journey</h4>
          <?php 
                if($companiesanddrivers_Type=="Company"){ 
     echo "<form method='POST'>
              <input type='' name='companiesanddrivers_No' value='$companiesanddrivers_No' hidden>
              <label>Pick a Bus</label>
              <select name='PickABus' class= 'form-control' required>
                <option></option>
                $PickABus
              </select>
              <label>Price Per Ticket (N$)</label>
              <input type='number' name='PricePerTicket' class= 'form-control' required>
              <label>Departure Date</label>
              <input type='date' name='DepDate' class= 'form-control' required>
              <label>Departure Time</label>
              <input type='time' name='DepTime' class= 'form-control' required>
               <label>Estimated Duration (hours)</label>
              <input type='number' name='EstimatedDuration' class= 'form-control' required>

              <label>Departure From (TOWN)</label>
              <input type='' name='DepartureFrom' class= 'form-control' required>
              <label>Boarding Area</label>
              <input type='' name='BoardingArea' class= 'form-control' required>
              <label>Departure Too (TOWN)</label>
              <input type='' name='DepartureToo' class= 'form-control' required>

              <label>Routes to be taken</label>
              <textarea name='RoutesTaken' class= 'form-control' required></textarea>
              <label>Allow Hitchhikers</label><br>
              <input type='radio' name='AllowHitchhikers' required value='Yes'> Yes
              <input type='radio' name='AllowHitchhikers' required value='No'> No
              <br>
              <label>Select Driver</label>
              <select class= 'form-control' name='TeamOfDrivers' required>
               <option></option>
                $PickDrivers
               </select>
              <button name='CreateNewJourney' class='btn btn-success btn-block'><b>Create New Journey</b></button>
            </form>";
                }elseif ($companiesanddrivers_Type=="Independent Driver") { 
      echo "<form method='POST'>
              <input type='' name='companiesanddrivers_No' value='$companiesanddrivers_No' hidden>
              <label>Pick a Bus</label>
              <select name='PickABus' class= 'form-control' required>
                <option></option>
                $PickABus
              </select>
              <label>Price Per Ticket (N$)</label>
              <input type='number' name='PricePerTicket' class= 'form-control' required>
              <label>Departure Date</label>
              <input type='date' name='DepDate' class= 'form-control' required>
              <label>Departure Time</label>
              <input type='time' name='DepTime' class= 'form-control' required>
               <label>Estimated Duration (hours)</label>
              <input type='number' name='EstimatedDuration' class= 'form-control' required>

              <label>Departure From (TOWN)</label>
              <input type='' name='DepartureFrom' class= 'form-control' required>
              <label>Boarding Area</label>
              <input type='' name='BoardingArea' class= 'form-control' required>
              <label>Departure Too (TOWN)</label>
              <input type='' name='DepartureToo' class= 'form-control' required>

              <label>Routes to be taken</label>
              <textarea name='RoutesTaken' class= 'form-control' required></textarea>
              <label>Allow Hitchhikers</label><br>
              <input type='radio' name='AllowHitchhikers' required value='Yes'> Yes
              <input type='radio' name='AllowHitchhikers' required value='No'> No
              <br>
              <label>Select Driver</label>
              <select class= 'form-control' name='TeamOfDrivers' required>
                   <option value='$companiesanddrivers_No'>$companiesanddrivers_Name</option>
              </select>
              <button name='CreateNewJourney' class='btn btn-success btn-block'><b>Create New Journey</b></button>
            </form>";
                }
                 ?>  
          </div>
        </div>
      </div> 
    </div>
  </div>
</div>

</body>
</html>
