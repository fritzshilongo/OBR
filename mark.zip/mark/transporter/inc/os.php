<?php
if (isset($_GET['logout'])) {
  session_start();
  session_destroy();
  header('Location: ../');
}
?> 
<?php
session_start();
//error_reporting(0);

$con; 

    $loguser = $_SESSION['TRANSPORTERloguser'];
    $username = $_SESSION['TRANSPORTERemail'];
    $password = $_SESSION['TRANSPORTERpassword']; 

$con;

//collect
  $query = mysqli_query($con, 'SELECT * FROM companiesanddrivers WHERE companiesanddrivers_Type = "'.$loguser.'" 
                                                                    AND companiesanddrivers_Email = "'.$username.'" 
                                                                    AND companiesanddrivers_Password = "'.$password.'"');

    $count = mysqli_num_rows($query);
    if ($count == 0) {
       echo "<script type='text/javascript'> alert('User type, email or password changed, please log in with new details');</script>"; 
      header('Location: ../');
      }else{
        while ($row = mysqli_fetch_array($query)) {
          
                   $companiesanddrivers_No = $row['companiesanddrivers_No'];

                  $companiesanddrivers_Type = $row['companiesanddrivers_Type'];
                 $companiesanddrivers_IdReg = $row['companiesanddrivers_IdReg'];
                  $companiesanddrivers_Name = $row['companiesanddrivers_Name'];

                    $companiesanddrivers_ContactNumberOne = $row['companiesanddrivers_ContactNumberOne'];
                    $companiesanddrivers_ContactNumberTwo = $row['companiesanddrivers_ContactNumberTwo'];
                         $companiesanddrivers_DateOfBirth = $row['companiesanddrivers_DateOfBirth'];

                  $companiesanddrivers_Email = $row['companiesanddrivers_Email'];
               $companiesanddrivers_Password = $row['companiesanddrivers_Password'];
               $companiesanddrivers_JoinDate = $row['companiesanddrivers_JoinDate'];  

if ($companiesanddrivers_Type=="Independent Driver") {
               $Biodetails .="<a href=''><h2 style='text-transform:uppercase;;'>$companiesanddrivers_Type</h2></a>
                                <hr>
                             <form method = 'POST'>
                             <input name='companiesanddrivers_No' value ='$companiesanddrivers_No' hidden required> 
                                <label>Id Number</label> 
                                <input name='companiesanddrivers_IdReg' value ='$companiesanddrivers_IdReg' class='form-control' required> 
                                <label>Name</label> 
                                <input name='companiesanddrivers_Name' value ='$companiesanddrivers_Name' class='form-control' required>
                                <label>Contact Number 1</label> 
                                <input name='companiesanddrivers_ContactNumberOne' value ='$companiesanddrivers_ContactNumberOne' class='form-control' required> 
                                <label>Contact Number 2</label> 
                                <input name='companiesanddrivers_ContactNumberTwo' value ='$companiesanddrivers_ContactNumberTwo' class='form-control' required>
                                <label>Daate of Birth</label>
                                <input type=date name='companiesanddrivers_DateOfBirth' value ='$companiesanddrivers_DateOfBirth' class='form-control' required>
                                <label>Email</label>
                                <input type='email' name='companiesanddrivers_Email' value ='$companiesanddrivers_Email' class='form-control' required> 
                                <label>Join Date</label><br>
                                $companiesanddrivers_JoinDate
                               
                            </form>
                                ";
}elseif($companiesanddrivers_Type=="Company"){
               $Biodetails .="<a href=''><h2 style='text-transform:uppercase;;'>$companiesanddrivers_Type</h2></a>
                                <hr>
                             <form method = 'POST'>
                             <input name='companiesanddrivers_No' value ='$companiesanddrivers_No' hidden required> 
                                <label>Registration Number</label> 
                                <input name='companiesanddrivers_IdReg' value ='$companiesanddrivers_IdReg' class='form-control' required> 
                                <label>Company Name</label> 
                                <input name='companiesanddrivers_Name' value ='$companiesanddrivers_Name' class='form-control' required>
                                <label>Contact Number 1</label> 
                                <input name='companiesanddrivers_ContactNumberOne' value ='$companiesanddrivers_ContactNumberOne' class='form-control' required> 
                                <label>Contact Number 2</label> 
                                <input name='companiesanddrivers_ContactNumberTwo' value ='$companiesanddrivers_ContactNumberTwo' class='form-control' required> 
                                <label>Email</label>
                                <input type='email' name='companiesanddrivers_Email' value ='$companiesanddrivers_Email' class='form-control' required> 
                                <label>Join Date</label><br>
                                $companiesanddrivers_JoinDate
                                 
                            </form>
                                ";
}


               


        }
   }

?>




<?php  

$con;

//collect
  $query = mysqli_query($con, 'SELECT * FROM buses WHERE BusesCOMPANY = "'.$companiesanddrivers_No.'"  ');

    $count = mysqli_num_rows($query);
    if ($count == 0) { 

      }else{
        while ($row = mysqli_fetch_array($query)) {
          
                   $BusesNO = $row['BusesNO'];

                  $BusesCOMPANY = $row['BusesCOMPANY'];
                  $BusesIMAGE = $row['BusesIMAGE'];
                  $BusesNUMBER = $row['BusesNUMBER'];

                    $BusesNAME = $row['BusesNAME'];
                    $BusesPLATE = ucwords($row['BusesPLATE']);
                    $BusesSEATS = $row['BusesSEATS'];

                  $BusesKNOWNFOR = $row['BusesKNOWNFOR'];



      $PickABus .="<option value = '$BusesNO'>$BusesPLATE $BusesNAME</option>";
      $ALLBUSES .="<li> 
                      <center>
                      <form method=POST>
                      <input value='$BusesNO' name='BusesNO' hidden>
                        <img src='buses/$BusesIMAGE' height='100' width='100'><br>
                        <b>Plate:</b> <i>$BusesPLATE</i><br>
                        <b>Bus:</b> $BusesNAME <br> 
                        <button class='badge' name='deleteBUS' style='background-color:red;color:white;'>Delete Bus </button>
                      <center>   
                      </form>
                    </li><hr>";

               


        }
   }

?> 


<?php  

$con;

//collect
  $query = mysqli_query($con, 'SELECT * FROM drivers WHERE DriversCOMPANY = "'.$companiesanddrivers_No.'"  ');

    $count = mysqli_num_rows($query);
    if ($count == 0) { 

      }else{
        while ($row = mysqli_fetch_array($query)) {
          
                   $DriversNO = $row['DriversNO'];

                  $DriversCOMPANY = $row['DriversCOMPANY'];
                  $DriversIMAGE = $row['DriversIMAGE'];
                  $DriversIDNUMBER = $row['DriversIDNUMBER'];

                    $DriversNAMESURNAME = $row['DriversNAMESURNAME'];
                    $DriversCONTACTONE = $row['DriversCONTACTONE'];
                    $DriversCONTACTTWO = $row['DriversCONTACTTWO'];

                  $DriversDATEOFBIRTH = $row['DriversDATEOFBIRTH'];

      $PickDrivers .="<option value = '$DriversNO'>$DriversNAMESURNAME ID: $DriversIDNUMBER</option>";
      $driv = "";
    $ALLDRIVERS .= "<li> 
                      <center>
                      <form method=POST>
                      <input value='$DriversNO' name='DriversNO' hidden>
                        <img src='drivers/$DriversIMAGE' height='100' width='100'><br>
                        $DriversNAMESURNAME <br>
                        <b>ID:</b> $DriversIDNUMBER<br> 
                        <button class='badge' name='deleteDRIVER' style='background-color:red;color:white;'>Delete Driver</button>
                      </center><hr>
                      </form>
                    </li>";
      

               


        }
   }

?>





<?php  
if ($companiesanddrivers_Type == "Independent Driver") {
  $HIDETHIS = '';
}elseif($companiesanddrivers_Type == "Company"){
  $HIDETHIS = ' JOIN drivers ON drivers.DriversNO = journeys.JourneysDRIVERS ';
}

$con;

//collect
  $query = mysqli_query($con, 'SELECT * FROM journeys 
                               JOIN buses ON buses.BusesNO = journeys.JourneysBUS
                               '.$HIDETHIS.'
                               WHERE journeys.JourneysCOMPANY = "'.$companiesanddrivers_No.'"
                               GROUP BY journeys.JourneysNO  ');

    $count = mysqli_num_rows($query);
    if ($count == 0) { 

      }else{
        while ($row = mysqli_fetch_array($query)) {
          //Journey Table
                   $JourneysNO = $row['JourneysNO'];
                  $JourneysCOMPANY = $row['JourneysCOMPANY'];
                  $JourneysBUS = $row['JourneysBUS'];
                  $JourneysTICKETPRICE = $row['JourneysTICKETPRICE'];
                  $JourneysSEATS = $row['JourneysSEATS'];
                  $JourneysTAKEN = $row['JourneysTAKEN'];
                    $JourneysDEPDATE = $row['JourneysDEPDATE'];
                    $JourneysDEPTIME = $row['JourneysDEPTIME'];
                    $JourneysDURATION = $row['JourneysDURATION'];
                  $JourneysDEPFROM = $row['JourneysDEPFROM'];
                  $JourneysBOARDINGAREA = $row['JourneysBOARDINGAREA'];
                  $JourneysDEPTOO = $row['JourneysDEPTOO'];
                  $JourneysROUTESTOBETAKEN = $row['JourneysROUTESTOBETAKEN'];
                  $JourneysHITCHHIKERS = $row['JourneysHITCHHIKERS'];
                  $JourneysDRIVERS = $row['JourneysDRIVERS'];
                  $JourneysADDEDON = $row['JourneysADDEDON'];

        //Drivers
                   $DriversNO = $row['DriversNO'];
                  $DriversCOMPANY = $row['DriversCOMPANY'];
                  $DriversIMAGE = $row['DriversIMAGE'];
                  $DriversIDNUMBER = $row['DriversIDNUMBER'];
                    $DriversNAMESURNAME = $row['DriversNAMESURNAME'];
                    $DriversCONTACTONE = $row['DriversCONTACTONE'];
                    $DriversCONTACTTWO = $row['DriversCONTACTTWO'];
                  $DriversDATEOFBIRTH = $row['DriversDATEOFBIRTH'];

        //Buses
                  $BusesNO = $row['BusesNO'];
                  $BusesCOMPANY = $row['BusesCOMPANY'];
                  $BusesIMAGE = $row['BusesIMAGE'];
                  $BusesNUMBER = $row['BusesNUMBER'];
                    $BusesNAME = $row['BusesNAME'];
                    $BusesPLATE = ucwords($row['BusesPLATE']);
                    $BusesSEATS = $row['BusesSEATS'];
                  $BusesKNOWNFOR = $row['BusesKNOWNFOR'];

mysqli_query($con,'UPDATE journeys SET journeys.JourneysSEATS = '.$BusesSEATS.' WHERE  journeys.JourneysNO = '.$JourneysNO.' ');


$TODAY = date('Y-m-d', strtotime('Today'));
if ($TODAY < $JourneysDEPDATE) {

$then = $JourneysDEPDATE;;
$then = new DateTime($then);
 
$now = new DateTime();
 
$sinceThen = $then->diff($now);
 
//Combined
if ($sinceThen->y > 0) {
 $Y = $sinceThen->y.' years ';
}if ($sinceThen->m > 0) {
 $M = $sinceThen->m.' months ';
}if ($sinceThen->d > 0) {
 $D = $sinceThen->d.' days ';
}
//if ($sinceThen->h > 0) {
 //echo $sinceThen->h.' hours ';
//}if ($sinceThen->i > 0) {
 //echo $sinceThen->i.' minutes';
//}
// echo " to go";
 }else{
  $YMD = "<small class='badge' style='background-color:red;color:white;'>Date Passed</small>";
 }
    $ALLJOURNEY .= "<li> 
                        <b>Date:</b> $JourneysDEPDATE<br>
                        <small>($YMD $Y $M $D)</small><br>
                        <b>Time:</b> $JourneysDEPTIME<br>
                        <b>From:</b> $JourneysDEPFROM <b>To:</b> $JourneysDEPTOO<br>
                        <b>Driver:</b> $DriversNAMESURNAME<br>
                        <b>Bus:</b> <i>$BusesPLATE</i> $BusesNAME <br>
                        <b>Total Seats:</b> $JourneysSEATS 
                        <hr>
                    </li>";
      

               


        }
   }

?>
<?php

$con;
//collect
  $query = mysqli_query($con, 'SELECT journeys.JourneysNO, journeys.JourneysDEPFROM, 
                                      journeys.JourneysDEPTOO, journeys.JourneysDEPDATE, 
                                      journeys.JourneysDEPTIME, buses.BusesIMAGE,buses.BusesSEATS, 
                                      COUNT(journeys.JourneysNO) AS "BOOKERS"
                                 FROM bookings 
                                 JOIN journeys 
                                   ON  journeys.JourneysNO = bookings.bookingsJOURNEYNO 
                                 JOIN buses 
                                   ON buses.BusesNO = journeys.JourneysBUS
                                WHERE journeys.JourneysCOMPANY = "'.$companiesanddrivers_No.'" 
                                GROUP BY journeys.JourneysNO    ');

    $countbookings = mysqli_num_rows($query);
    if ($countbookings == 0) {
       $ALLBOOKINGS = ""; 
      }else{
        while ($row = mysqli_fetch_array($query)) {
          //bookings
                         $bookingsNO = $row['bookingsNO'];
                  $bookingsTICKETNUM = $row['bookingsTICKETNUM'];
                  $bookingsJOURNEYNO = $row['bookingsJOURNEYNO'];
                  $bookingsNAMESURNAME = $row['bookingsNAMESURNAME'];
                    $bookingsCELLPHONE = $row['bookingsCELLPHONE'];
                        $bookingsEMAIL = $row['bookingsEMAIL'];
                         $bookingsSEATNUMBER = $row['bookingsSEATNUMBER'];
                           $bookingsDATETIME = $row['bookingsDATETIME'];  
                           $BOOKERS = $row['BOOKERS'];  
          //journey
                  $JourneysNO = $row['JourneysNO'];
                  $JourneysCOMPANY = $row['JourneysCOMPANY'];
                  $JourneysBUS = $row['JourneysBUS'];
                  $JourneysTICKETPRICE = $row['JourneysTICKETPRICE'];
                  $JourneysSEATS = $row['JourneysSEATS'];
                  $JourneysTAKEN = $row['JourneysTAKEN'];
                    $JourneysDEPDATE = $row['JourneysDEPDATE'];
                    $JourneysDEPTIME = $row['JourneysDEPTIME'];
                    $JourneysDURATION = $row['JourneysDURATION'];
                  $JourneysDEPFROM = $row['JourneysDEPFROM'];
                  $JourneysBOARDINGAREA = $row['JourneysBOARDINGAREA'];
                  $JourneysDEPTOO = $row['JourneysDEPTOO'];
                  $JourneysROUTESTOBETAKEN = $row['JourneysROUTESTOBETAKEN'];
                  $JourneysHITCHHIKERS = $row['JourneysHITCHHIKERS'];
                  $JourneysDRIVERS = $row['JourneysDRIVERS'];
                  $JourneysADDEDON = $row['JourneysADDEDON']; 
          //Buses
                  $BusesNO = $row['BusesNO'];
                  $BusesCOMPANY = $row['BusesCOMPANY'];
                  $BusesIMAGE = $row['BusesIMAGE'];
                  $BusesNUMBER = $row['BusesNUMBER'];
                    $BusesNAME = $row['BusesNAME'];
                    $BusesPLATE = ucwords($row['BusesPLATE']);
                    $BusesSEATS = $row['BusesSEATS'];
                  $BusesKNOWNFOR = $row['BusesKNOWNFOR'];

 $timestamp = strtotime(''.$JourneysDEPTIME.'') + 60*60*$JourneysDURATION;
$ArrivalTime = date('H:i', $timestamp);

$TODAY = date('Y-m-d', strtotime('Today'));
if ($TODAY < $JourneysDEPDATE) {

$then = $JourneysDEPDATE;;
$then = new DateTime($then);
 
$now = new DateTime();
 
$sinceThen = $then->diff($now);
 
//Combined
if ($sinceThen->y > 0) {
 $Y = $sinceThen->y.' years ';
}if ($sinceThen->m > 0) {
 $M = $sinceThen->m.' months ';
}if ($sinceThen->d > 0) {
 $D = $sinceThen->d.' days ';
}
//if ($sinceThen->h > 0) {
 //echo $sinceThen->h.' hours ';
//}if ($sinceThen->i > 0) {
 //echo $sinceThen->i.' minutes';
//}
// echo " to go";
 }else{
  $YMD = "<small class='badge' style='background-color:red;color:white;'>Date Passed</small>";
 }
     $ALLBOOKINGS .= "<tr>
                        <td><img src='buses/$BusesIMAGE' height='100' width='100' class='img-rounded' align='right'></td>
                        <td>$JourneysDEPFROM</td>
                        <td>$JourneysDEPTOO</td>
                        <td>$JourneysDEPDATE<br> $Y $M $D</td>
                        <td>$JourneysDEPTIME</td> 
                        <td><center><h3>$BOOKERS / $BusesSEATS</h3></td>
                      </tr>"; 

        }
   }

?>