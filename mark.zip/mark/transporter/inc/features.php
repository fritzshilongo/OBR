<?php
 


if (isset($_POST['AddBus'])) {
  if(isset($_FILES["image_upload"]["name"])) 
{
 $name = $_FILES["image_upload"]["name"];
 $size = $_FILES["image_upload"]["size"];
 $ext = end(explode(".", $name));
 $allowed_ext = array("png", "jpg", "jpeg");
 if(in_array($ext, $allowed_ext))
 {
  if($size < (1024*1024))
  {
   $new_image = '';
   $new_name = rand() . '.' . $ext;

   $companiesanddrivers_No = $_POST['companiesanddrivers_No']; 
   $BusNumber = $_POST['BusNumber'];

   $BusName = $_POST['BusName'];
   $PlateNumber = $_POST['PlateNumber'];
   $NumberofSeats = $_POST['NumberofSeats'];
   $RoutesKnownFor = $_POST['RoutesKnownFor'];

   $sql = 'INSERT INTO buses (BusesCOMPANY, BusesIMAGE, BusesNUMBER, BusesNAME, BusesPLATE, BusesSEATS, BusesKNOWNFOR) 
           VALUES ("'.$companiesanddrivers_No.'","'.$new_name.'","'.$BusNumber.'","'.$BusName.'","'.$PlateNumber.'","'.$NumberofSeats.'","'.$RoutesKnownFor.'")   ';
   mysqli_query($con, $sql);

   $path = 'buses/' . $new_name;
   list($width, $height) = getimagesize($_FILES["image_upload"]["tmp_name"]);
   if($ext == 'png')
   {
    $new_image = imagecreatefrompng($_FILES["image_upload"]["tmp_name"]);
   }
   if($ext == 'jpg' || $ext == 'jpeg')  
            {  
               $new_image = imagecreatefromjpeg($_FILES["image_upload"]["tmp_name"]);  
            }
            $new_width=200;
            $new_height = ($height/$width)*200;
            $tmp_image = imagecreatetruecolor($new_width, $new_height);
            imagecopyresampled($tmp_image, $new_image, 0, 0, 0, 0, $new_width, $new_height, $width, $height);
            imagejpeg($tmp_image, $path, 100);
            imagedestroy($new_image);
            imagedestroy($tmp_image); 
  }
  else
  {
   echo 'Image File size must be less than 1 MB';
  }
 }
 else
 {
  echo 'Invalid Image File';
 }
}
}
?> 



<?php
if (isset($_POST['AddDriver'])) {
  if(isset($_FILES["image_upload"]["name"])) 
{
 $name = $_FILES["image_upload"]["name"];
 $size = $_FILES["image_upload"]["size"];
 $ext = end(explode(".", $name));
 $allowed_ext = array("png", "jpg", "jpeg");
 if(in_array($ext, $allowed_ext))
 {
  if($size < (1024*1024))
  {
   $new_image = '';
   $new_name = rand() . '.' . $ext;

   $companiesanddrivers_No = $_POST['companiesanddrivers_No']; 
   $idnumber = $_POST['idnumber'];

   $Firstname = $_POST['Firstname'];
   $contactnumber1 = $_POST['contactnumber1'];
   $contactnumber2 = $_POST['contactnumber2'];
   $dateofbirth = $_POST['dateofbirth'];

   $sql = 'INSERT INTO drivers (DriversCOMPANY, DriversIMAGE, DriversIDNUMBER, 
                               DriversNAMESURNAME, DriversCONTACTONE, DriversCONTACTTWO, 
                               DriversDATEOFBIRTH) 
                      VALUES ("'.$companiesanddrivers_No.'","'.$new_name.'","'.$idnumber.'",
                              "'.$Firstname.'","'.$contactnumber1.'","'.$contactnumber2.'",
                              "'.$dateofbirth.'")   ';
   mysqli_query($con, $sql);

   $path = 'drivers/' . $new_name;
   list($width, $height) = getimagesize($_FILES["image_upload"]["tmp_name"]);
   if($ext == 'png')
   {
    $new_image = imagecreatefrompng($_FILES["image_upload"]["tmp_name"]);
   }
   if($ext == 'jpg' || $ext == 'jpeg')  
            {  
               $new_image = imagecreatefromjpeg($_FILES["image_upload"]["tmp_name"]);  
            }
            $new_width=200;
            $new_height = ($height/$width)*200;
            $tmp_image = imagecreatetruecolor($new_width, $new_height);
            imagecopyresampled($tmp_image, $new_image, 0, 0, 0, 0, $new_width, $new_height, $width, $height);
            imagejpeg($tmp_image, $path, 100);
            imagedestroy($new_image);
            imagedestroy($tmp_image); 
  }
  else
  {
   echo 'Image File size must be less than 1 MB';
  }
 }
 else
 {
  echo 'Invalid Image File';
 }
}
}
?> 


<?php



if (isset($_POST['CreateNewJourney'])) {
   $companiesanddrivers_No = $_POST['companiesanddrivers_No'];
   $PickABus = $_POST['PickABus'];
   $PricePerTicket = $_POST['PricePerTicket'];
   $DepDate = $_POST['DepDate'];

   $DepTime = $_POST['DepTime'];
   $EstimatedDuration = $_POST['EstimatedDuration'];
   $DepartureFrom = $_POST['DepartureFrom'];
   $BoardingArea = $_POST['BoardingArea'];

   $DepartureToo = $_POST['DepartureToo'];
   $RoutesTaken = $_POST['RoutesTaken']; 
   $AllowHitchhikers = $_POST['AllowHitchhikers'];

   $TeamOfDrivers = $_POST['TeamOfDrivers']; 
   include '../connection.php';
   $sql ='INSERT INTO journeys (JourneysCOMPANY, JourneysBUS, 
                                JourneysSEATS, JourneysTAKEN, 
                                JourneysTICKETPRICE, 
                                JourneysDEPDATE, JourneysDEPTIME, JourneysDURATION, 
                                JourneysDEPFROM, JourneysBOARDINGAREA, JourneysDEPTOO, 
                                JourneysROUTESTOBETAKEN, JourneysHITCHHIKERS, JourneysDRIVERS,
                                JourneysADDEDON)
                        VALUES ("'.$companiesanddrivers_No.'","'.$PickABus.'", 
                                0, 0,
                                "'.$PricePerTicket.'",
                                "'.$DepDate.'","'.$DepTime.'","'.$EstimatedDuration.'",
                                "'.$DepartureFrom.'","'.$BoardingArea.'","'.$DepartureToo.'",
                                "'.$RoutesTaken.'","'.$AllowHitchhikers.'","'.$TeamOfDrivers.'",
                                CURRENT_TIMESTAMP)';

   if (mysqli_query($con, $sql)) {
     
   }else{ 
    echo "<div class='alert alert-danger'>
              <strong>failed to add journey</strong>
           </div>";
   }

}
?>