<?php   
$con;
 $SelectDate = "";
//collect
  $query = mysqli_query($con, 'SELECT * FROM journeys ');

    $count = mysqli_num_rows($query);
    if ($count == 0) { 
     $SelectDate = "<option>No Journeys Found on any date</option>";  
      }else{
        while ($row = mysqli_fetch_array($query)) { 
                    $JourneysDEPDATE = $row['JourneysDEPDATE']; 


    $SelectDate .= "<option value='$JourneysDEPDATE'>$JourneysDEPDATE</option>";              


        }
   }

?>


<?php  
$FINDJOURNEY = " ";
if (isset($_GET['searchjourneys'])) {
  $selectjourneys = $_GET['selectjourneys'];
  if ($selectjourneys == "View All") {
    $CURRENTDATE = "<option>$selectjourneys</option>";  
    $FINDJOURNEY = " ";
  }else{  
    $CURRENTDATE = "<option>$selectjourneys</option>";   
    $FINDJOURNEY = ' WHERE journeys.JourneysDEPDATE = "'.$selectjourneys.'" ';
 }
}  

$con;
 $ALLJOURNIES = "";
//collect
  $query = mysqli_query($con, 'SELECT * FROM journeys 
                               JOIN companiesanddrivers ON companiesanddrivers.companiesanddrivers_No = journeys.JourneysCOMPANY
                               JOIN buses ON buses.BusesNO = journeys.JourneysBUS
                                
                                '.$FINDJOURNEY.'
                               GROUP BY journeys.JourneysNO  ');

    $count = mysqli_num_rows($query);
    if ($count == 0) { 
     $ALLJOURNIES = "<div class='alert alert-danger' >
                       <strong>No Journeys added yet</strong>
                     </div>";
      }else{
        while ($row = mysqli_fetch_array($query)) {

          //CompanyandDrivers
            $companiesanddrivers_No = $row['companiesanddrivers_No'];
                  $companiesanddrivers_Type = $row['companiesanddrivers_Type'];
                 $companiesanddrivers_IdReg = $row['companiesanddrivers_IdReg'];
                  $companiesanddrivers_Name = $row['companiesanddrivers_Name'];
                    $companiesanddrivers_ContactNumberOne = $row['companiesanddrivers_ContactNumberOne'];
                    $companiesanddrivers_ContactNumberTwo = $row['companiesanddrivers_ContactNumberTwo'];
                         $companiesanddrivers_DateOfBirth = $row['companiesanddrivers_DateOfBirth'];
                  $companiesanddrivers_Email = $row['companiesanddrivers_Email'];
               $companiesanddrivers_Password = $row['companiesanddrivers_Password'];
               $companiesanddrivers_JoinDate = $row['companiesanddrivers_JoinDate']; 

          //Journey Table
                   $JourneysNO = $row['JourneysNO'];
                  $JourneysCOMPANY = $row['JourneysCOMPANY'];
                  $JourneysBUS = $row['JourneysBUS'];
                  $JourneysTICKETPRICE = $row['JourneysTICKETPRICE'];
                         $JourneysSEATS = $row['JourneysSEATS'];
                         $JourneysTAKEN = $row['JourneysTAKEN'];
                    $JourneysDEPDATE = $row['JourneysDEPDATE'];
                    $JourneysDEPTIME = $row['JourneysDEPTIME'];
                    $JourneysDURATION = $row['JourneysDURATION'];
                  $JourneysDEPFROM = $row['JourneysDEPFROM'];
                  $JourneysBOARDINGAREA = $row['JourneysBOARDINGAREA'];
                  $JourneysDEPTOO = $row['JourneysDEPTOO'];
                  $JourneysROUTESTOBETAKEN = $row['JourneysROUTESTOBETAKEN'];
                  $JourneysHITCHHIKERS = $row['JourneysHITCHHIKERS'];
                  $JourneysDRIVERS = $row['JourneysDRIVERS'];
                  $JourneysADDEDON = $row['JourneysADDEDON'];
 

        //Buses
                  $BusesNO = $row['BusesNO'];
                  $BusesCOMPANY = $row['BusesCOMPANY'];
                  $BusesIMAGE = $row['BusesIMAGE'];
                  $BusesNUMBER = $row['BusesNUMBER'];
                    $BusesNAME = $row['BusesNAME'];
                    $BusesPLATE = ucwords($row['BusesPLATE']);
                    $BusesSEATS = $row['BusesSEATS'];
                  $BusesKNOWNFOR = $row['BusesKNOWNFOR'];


$TODAY = date('Y-m-d', strtotime('Today'));
$SEATSLEFT = $JourneysSEATS - $JourneysTAKEN;

if ($JourneysTAKEN >= $JourneysSEATS) {
  $disabled = 'disabled';
  $bookedmessage = '<h4>Fully Booked</h4>';
}else{
  $disabled = '';
  $bookedmessage = '<h4>Book Now</h4>'; 
}

if ($TODAY < $JourneysDEPDATE) {

$then = $JourneysDEPDATE;;
$then = new DateTime($then);
 
$now = new DateTime();
 
$sinceThen = $then->diff($now);
 
//Combined
if ($sinceThen->y > 0) {
 $Y = $sinceThen->y.' years ';
}if ($sinceThen->m > 0) {
 $M = $sinceThen->m.' months ';
}if ($sinceThen->d > 0) {
 $D = $sinceThen->d.' days ';
}
//if ($sinceThen->h > 0) {
 //echo $sinceThen->h.' hours ';
//}if ($sinceThen->i > 0) {
 //echo $sinceThen->i.' minutes';
//}
 
 $extraago =" left";
 $passed =" ";
 $YMD = "<small class='badge' style='background-color:green;color:white;'>$Y $M $D $extraago</small>";
 $disabledD = '';
 }


 elseif($TODAY == $JourneysDEPDATE){
  $passed =" Today";
  $YMD = "<small class='badge' style='background-color:blue;color:white;'>$passed $JourneysDEPDATE</small>";
  if ($JourneysTAKEN >= $JourneysSEATS) {
  $disabled = 'disabled';
  $bookedmessage = '<h4>Fully Booked</h4>';
}else{
  $disabled = '';
  $bookedmessage = '<h4>Book Now</h4>'; 
} 


 }elseif($TODAY > $JourneysDEPDATE){
  $then = $JourneysDEPDATE;;
$then = new DateTime($then);
 
$now = new DateTime();
 
$sinceThen = $then->diff($now);
 
//Combined
if ($sinceThen->y > 0) {
 $Y = $sinceThen->y.' years ';
}if ($sinceThen->m > 0) {
 $M = $sinceThen->m.' months ';
}if ($sinceThen->d > 0) {
 $D = $sinceThen->d.' days ';
}

  $extraago =" ago";
  $passed =" Passed";
  $YMD = "<small class='badge' style='background-color:red;color:white;'>$passed $Y $M $D $extraago</small>";
  $disabledD = 'disabled'; 
  $color = "" ;
 }
    $ALLJOURNIES .= "<div class='col-sm-4'> 
                     <div class=well>
                        <center>
                        <b>From:</b> $JourneysDEPFROM  <b>To:</b> $JourneysDEPTOO<br> 
                        $YMD<br>  
                        <img src= 'transporter/buses/$BusesIMAGE' class='img-rounded' height='100' width='100'><br>
                        <b><i>$BusesPLATE</i> $BusesNAME</b> <br>
                        <b><i>Bus No:</i> $BusesNUMBER</b> <br>
                        $companiesanddrivers_Type <br>
                        $companiesanddrivers_Name                                
                        </center>

                        <b>Date:</b> $JourneysDEPDATE<br>                        
                        <b>Time:</b> $JourneysDEPTIME<br> 
                         <form method = 'get' action='booknow.php'> 
                         <input name='cmy' value='$companiesanddrivers_No' hidden>
                          <button name='bn' value='$JourneysNO' class='btn btn-primary btn-xs btn-block' $disabled $disabledD>
                          <b>
                          N$$JourneysTICKETPRICE
                          $bookedmessage
                          </button>
                         </form>
                        <hr>
                    </div>
                    </div>";
      

               


        }
   }


 if (isset($_POST['PayNow'])) {
  //journey
  $JourneysNO = $_POST['JourneysNO'];
  $JourneysDEPFROM = $_POST['JourneysDEPFROM'];
  $JourneysDEPTOO = $_POST['JourneysDEPTOO'];
  $JourneysBOARDINGAREA = $_POST['JourneysBOARDINGAREA'];
  $JourneysDEPDATE = $_POST['JourneysDEPDATE'];
  $JourneysDEPTIME = $_POST['JourneysDEPTIME'];
  $JourneysDURATION = $_POST['JourneysDURATION'];
  $ArrivalTime = $_POST['ArrivalTime'];
  $JourneysROUTESTOBETAKEN = $_POST['JourneysROUTESTOBETAKEN'];
  //bus
  $BusesNAME = $_POST['BusesNAME'];
  $BusesPLATE = $_POST['BusesPLATE'];
  //company driver
  $companiesanddrivers_Name = $_POST['companiesanddrivers_Name'];
  $companiesanddrivers_ContactNumberOne = $_POST['companiesanddrivers_ContactNumberOne'];
  $companiesanddrivers_ContactNumberTwo = $_POST['companiesanddrivers_ContactNumberTwo']; 
  //information
  $NameSurname = $_POST['NameSurname'];
  $CellphoneNumber = $_POST['CellphoneNumber'];
  $Email = $_POST['Email']; 
  $SeatNumber = $_POST['SeatNumber'];  

  $Ticketnumber = '#'.rand(10001,99999);
  
  $sql = 'INSERT INTO bookings (bookingsJOURNEYNO, bookingsTICKETNUM, bookingsNAMESURNAME, bookingsCELLPHONE, bookingsEMAIL, bookingsSEATNUMBER, bookingsDATETIME) 
                        VALUES ("'.$JourneysNO.'","'.$Ticketnumber.'",  "'.$NameSurname.'", "'.$CellphoneNumber.'", "'.$Email.'", "'.$SeatNumber.'", CURRENT_TIMESTAMP)';
  if (mysqli_query($con,$sql)) {
    $SYSALERT = "<div class='alert alert-success'>
                    <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                    <strong>SUCCESSFULLY BOOKED</strong> <br>
                    <b>FROM:</b> $JourneysDEPFROM <br>
                    <b>TO:</b> $JourneysDEPTOO <br>
                    <b>SEAT:</b> $SeatNumber <br>
                    <b>TICKET</B> $Ticketnumber
                 </div>";
    if (!empty($Email)) {
      $subject = "Bus Ticket Recipt";
      $header = "<no-reply> BUS TICKET SYSTEM";
      $message = 'TICKET NUM: '.$Ticketnumber.
                 '
                 FROM: '.$JourneysDEPFROM.' TO: '.$JourneysDEPTOO.
                 '
                 BOARDING AREA: '.$JourneysBOARDINGAREA.
                 '
                 DEPARTURE DATE: '.$JourneysDEPDATE.
                 '
                 DEPARTURE TIME: '.$JourneysDEPTIME.
                 '
                 DURATION (hours): '.$JourneysDURATION.
                 '
                 ARRIVAL TIME: '.$ArrivalTime. 

                 '
                 
                 NAME: '.$NameSurname.
                 '
                 CELL: '.$CellphoneNumber.
                 '
                 SEAT: '.$SeatNumber.

                 
                 '
                 DRIVER: '.$companiesanddrivers_Name.
                 '
                 CELL1: '.$companiesanddrivers_ContactNumberOne.
                 '
                 CELL2: '.$companiesanddrivers_ContactNumberTwo.

                 '
                 
                 BUS: '.$BusesNAME.
                 '
                 PLATES: '.$BusesPLATE;
      if (mail($Email, $subject, $message, $header)) {
       $SYSALERT1 = "<div class='alert alert-success'>
                    <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                    <strong>Recipt Successfully Sent</strong> TO $Email
                 </div>";
      }else{
        $SYSALERT1 = "<div class='alert alert-danger'>
                    <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                    <strong>Emailing Recipt failed</strong> no internet connection
                 </div>";
      }
    }
  }else{
    echo "<script type='text/javascript'> alert('Sorry, seat is unavailable');</script>"; 
  }
}
?>