<?php  
if (isset($_POST['SignUpDriver'])) {
  $usertype = $_POST['usertype'];
  $idnumber = $_POST['idnumber'];
  $Firstname = $_POST['Firstname'];
  $contactnumber1 = $_POST['contactnumber1'];
  $contactnumber2 = $_POST['contactnumber2'];
  $dateofbirth = $_POST['dateofbirth'];
  $email = $_POST['email'];
  $Password = $_POST['Password'];
//require 'connection.php';
  $sql = 'INSERT INTO companiesanddrivers (companiesanddrivers_Type,
                                                       companiesanddrivers_IdReg,
                                                       companiesanddrivers_Name,
                                                       companiesanddrivers_ContactNumberOne,
                                                       companiesanddrivers_ContactNumberTwo,
                                                       companiesanddrivers_DateOfBirth,
                                                       companiesanddrivers_Email,
                                                       companiesanddrivers_Password,
                                                       companiesanddrivers_JoinDate) 
                      VALUES ("'.$usertype.'",
                              "'.$idnumber.'",
                              "'.$Firstname.'",
                              "'.$contactnumber1.'",
                              "'.$contactnumber2.'",
                              "'.$dateofbirth.'",
                              "'.$email.'",
                              "'.$Password.'",
                              CURRENT_TIMESTAMP)';

  if (mysqli_query($con,$sql)) {
   $SYSTEMMES = "<div class='alert alert-success'>
                 <strong>Successfully registered on Bus Ticket System</strong>
                 </div>";
  $subject = 'New Driver Registered';
  $message = 'Greetings, Welcome to Bus Ticket System
                ACCOUNT TYPE: Independent Driver 
                '
              .'USERNAME: '.$email
              .' 
              PASSWORD: '.$Password
              .' 
              Log in at: www.acomhosting.co.za/mark/';
  $header = '<no-reply> Bus Ticket System';
  
  if (mail($email, $subject, $message, $header)) {
    $SYSTEMMES1 = "<div class='alert alert-success'>
                 <strong>Credentials Successfully Emailed</strong>
                 </div>";
  }else{
    $SYSTEMMES1 = "<div class='alert alert-danger'>
                 <strong>Emailing Credentials failed</strong> No internet connection
                 </div>";
  }
  }else{
    $SYSTEMMES = "<div class='alert alert-danger'>
                  <strong>ID: $idnumber or Email: $email Already Exists</strong> Failed to add new Driver
                  </div>";
  }
}
?>






<?php 
if (isset($_POST['SignUpCompany'])) {
  $usertype = $_POST['usertype'];
  $Regnumber = $_POST['Regnumber'];
  $companyname = $_POST['companyname'];
  $contactnumber1 = $_POST['contactnumber1'];
  $contactnumber2 = $_POST['contactnumber2']; 
  $email = $_POST['email'];
  $Password = $_POST['Password'];
//require 'connection.php';
              $sql = 'INSERT INTO companiesanddrivers (companiesanddrivers_Type,
                                                       companiesanddrivers_IdReg,
                                                       companiesanddrivers_Name,
                                                       companiesanddrivers_ContactNumberOne,
                                                       companiesanddrivers_ContactNumberTwo,
                                                       companiesanddrivers_DateOfBirth,
                                                       companiesanddrivers_Email,
                                                       companiesanddrivers_Password,
                                                       companiesanddrivers_JoinDate) 
                      VALUES ("'.$usertype.'",
                              "'.$Regnumber.'",
                              "'.$companyname.'",
                              "'.$contactnumber1.'",
                              "'.$contactnumber2.'",
                              CURRENT_TIMESTAMP,
                              "'.$email.'",
                              "'.$Password.'",
                              CURRENT_TIMESTAMP)';

  if (mysqli_query($con,$sql)) {
   $SYSTEMMES = "<div class='alert alert-success'>
                 <strong>Successfully registered</strong> <a href='index.php'>go to log in</a>
                 </div>";
  $subject = 'New Company Registered';
  $message = 'Greetings, Welcome to Bus Ticket System
                ACCOUNT TYPE: Company
                '
              .'USERNAME: '.$email
              .'
              PASSWORD: '.$Password
              .'
              Log in at: www.acomhosting.co.za/mark/';
  $header = '<no-reply> Bus Ticket System';
  
  if (mail($email, $subject, $message, $header)) {
    $SYSTEMMES1 = "<div class='alert alert-success'>
                 <strong>Credentials Successfully Emailed</strong>
                 </div>";
  }else{
    $SYSTEMMES1 = "<div class='alert alert-danger'>
                 <strong>Emailing Credentials failed</strong> No internet connection
                 </div>";
  }
  }else{
    $SYSTEMMES = "<div class='alert alert-danger'>
                  <strong>ID: $Regnumber or Email: $email Already Exists</strong> Failed to add new Company
                  </div>";
  }
}
?>